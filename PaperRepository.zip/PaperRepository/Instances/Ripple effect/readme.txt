The ripple effect instances are in .mat files and they can be opened with Matlab.

Within each file there are the following parameters:

M: sparse version of the node-arc adjacency matrix of the graph
b: vector with the supply and demands
cap (only for netgen instances): maximum flow capacity of an arc. In grid instances cap is one by default
cini: the initial cost vector c^0
d: vector with the 'partial damages.' The value of d^k (the vector of damages in the paper) is given by d^k=\sum_{i=k}^5d(i). Alternatively, just put d^k=40/1.5^k
p1: vector with the x-coordinates of the arcs' locations
p2: vector with the y-coordinates of the arcs' locations
q: vector with the ripple radii q^k

