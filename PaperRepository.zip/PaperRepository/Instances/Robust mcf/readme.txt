The robust mcf instances are in .mat files and they can be opened with Matlab.

Within each file there are the following parameters:

M: sparse version of the node-arc adjacency matrix of the graph
b: vector with the supply and demands of the defender
ba: vector with the supply and demands of the attacker
clb: vector with the lower bounds on the arcs' costs
cub: vector with the upper bounds on the arcs' costs
r: vector that shows the arcs in \widetilde A. If an entry has an    infinity then the defender does not know the flow on that arc
w: value of the optimal solution of the attacker
