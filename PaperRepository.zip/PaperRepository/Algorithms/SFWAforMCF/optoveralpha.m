function cnext=optoveralpha(A,b,mu,c,chat)
%M has the previous search points in a column fashion
[m,n]=size(A);
Q=[A;eye(n)];
nvars=2+m+n;
obj=zeros(nvars,1);
obj(1)=1;
tildef=[b;zeros(n,1)];
f=1/(2*mu)*[-Q*c-tildef*2*mu;c'*(chat-c)];
size(Q*Q')
size(chat-c)
J=-1/(4*mu)*[Q*Q', -Q*(chat-c);-(chat-c)'*Q',(chat-c)'*(chat-c)];
f=[1;f];
J=[zeros(1,nvars);zeros(1+m+n,1),J];

nlp=Cplex('quad');
nlp.Model.obj=obj;
nlp.Model.lb=[-inf;zeros(m+n+1,1)];
nlp.Model.ub=inf+zeros(m+n+2,1);
nlp.Model.rhs=1;
nlp.Model.lhs=-inf;
vec=zeros(1,nvars);
vec(nvars)=1;
nlp.Model.A=sparse(vec);
nlp.Model.sense='maximize';
nlp.addQCs(f,-J,'L',0);
nlp.solve();
x=nlp.Solution.x;
opt=x(nvars);
cnext=c+opt*(chat-c);



