function c=optoverconvex(A,b,mu,M)
%M has the previous search points in a column fashion
[m,n]=size(A);
p=size(M,2);
nvars=1+m+2*n+p;
obj=zeros(nvars,1);
obj(1)=1;
f=[1;-b;zeros(2*n+p,1)];

nnzeros=nnz(M)+n;
iv=zeros(nnzeros,1);
jv=iv;
vv=iv;
u=1;
for i=1:n
    iv(u)=i;
    jv(u)=1+n+m+i;
    vv(u)=-1;
    u=u+1;
    for j=1:p
        if (M(i,j)~=0)
            iv(u)=i;
            jv(u)=1+2*n+m+j;
            vv(u)=M(i,j);
            u=u+1;
        end
    end 
end
nlp=Cplex('quad');
nlp.Model.obj=obj;
nlp.Model.lb=[-inf;zeros(m+2*n+p,1)];
nlp.Model.ub=[inf;inf+ones(m+2*n,1);ones(p,1)];
nlp.Model.rhs=zeros(n,1);
nlp.Model.lhs=zeros(n,1);
nlp.Model.A=sparse(iv,jv,vv);
nlp.Model.sense='maximize';
Q=[A;eye(n)];
H=[zeros(1,nvars);zeros(m+n,1),Q*Q',-Q,zeros(m+n,p);zeros(n,1),-Q',eye(n),zeros(n,p);zeros(p,nvars)];
nlp.addRows(1,[zeros(1,1+2*n+m),ones(1,p)],1);
nlp.addQCs(f,H/(4*mu),'L',0);
nlp.Param.barrier.display.Cur=0;
nlp.solve();
x=nlp.Solution.x;
c=x(1+n+m+1:1+m+2*n);



