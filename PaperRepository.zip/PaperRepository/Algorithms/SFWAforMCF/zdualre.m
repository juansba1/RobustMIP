function [v,c,time,flag]=zdualre(M,c0,p1,p2,d,q,A,b,gap)
tic;
c0=c0';
[~,n]=size(M);
K=max(size(d));
nvars=n*(K+5)+2;
xM=max(p1);
xm=min(p1);
yM=max(p2);
ym=min(p2);
qmax=xM-xm+yM-ym;
flag=0;   
nnzeros=n*(6*K+7);
nrows=n*(K+3);
iv=zeros(nnzeros,1);
jv=zeros(nnzeros,1);
vv=zeros(nnzeros,1);
rhs=zeros(nrows,1);
lhs=rhs;
u=1;
z=0;
%def of \hat c
for i=1:n
    iv(u)=z+i;
    jv(u)=i;
    vv(u)=1;
    u=u+1;
    for k=1:K
        iv(u)=z+i;
        jv(u)=2+5*n+(k-1)*n+i;
        vv(u)=-d(k);
        u=u+1;         
    end
    rhs(z+i)=c0(i);
    lhs(z+i)=c0(i);
end
z=z+n;
%def of p1
for i=1:n
   iv(u)=z+i;
   jv(u)=n+1;
   vv(u)=-1;
   u=u+1;
   iv(u)=z+i;
   jv(u)=2+n+i;
   vv(u)=-1;
   u=u+1;
   iv(u)=z+i;
   jv(u)=2+2*n+i;
   vv(u)=1;
   u=u+1; 
   rhs(z+i)=-p1(i);
   lhs(z+i)=-p1(i);
end
z=z+n;
%def of p2
for i=1:n
   iv(u)=z+i;
   jv(u)=n+2;
   vv(u)=-1;
   u=u+1;
   iv(u)=z+i;
   jv(u)=2+3*n+i;
   vv(u)=-1;
   u=u+1;
   iv(u)=z+i;
   jv(u)=2+4*n+i;
   vv(u)=1;
   u=u+1; 
   rhs(z+i)=-p2(i);
   lhs(z+i)=-p2(i);
end
z=z+n;
%distances definition
for k=1:K
    for i=1:n
       iv(u)=z+n*(k-1)+i;
       jv(u)=2+n+i;
       vv(u)=1;
       u=u+1;
       iv(u)=z+n*(k-1)+i;
       jv(u)=2+2*n+i;
       vv(u)=1;
       u=u+1;
       iv(u)=z+n*(k-1)+i;
       jv(u)=2+3*n+i;
       vv(u)=1;
       u=u+1;
       iv(u)=z+n*(k-1)+i;
       jv(u)=2+4*n+i;
       vv(u)=1;
       u=u+1;
       iv(u)=z+n*(k-1)+i;
       jv(u)=2+5*n+(k-1)*n+i;
       vv(u)=qmax-q(k);
       u=u+1;
       rhs(z+n*(k-1)+i)=qmax;
       lhs(z+n*(k-1)+i)=-inf;
    end      
end
iv(u:nnzeros)=[];
jv(u:nnzeros)=[];
vv(u:nnzeros)=[];
%objective function and bounds
vec=zeros(nvars,1);
lb=vec;
%upper bounds
vec=c0;
for k=1:K
    vec=vec+d(k)*ones(n,1);
end
ub(1:n)=vec;
ub(n+1)=xM;
ub(n+2)=yM;
vec=xM-xm;
ub(n+3:2*n+2)=vec;
ub(2*n+3:3*n+2)=vec;
vec=yM-ym;
ub(3*n+3:4*n+2)=vec;
ub(4*n+3:5*n+2)=vec;
ub(5*n+3:nvars)=ones(n*K,1);

%obj
vec=zeros(nvars,1);
%ctype
ctype=blanks(nvars);
for i=1:5*n+2
    ctype(i)='C';
end
for i=5*n+3:nvars
    ctype(i)='B';
end

%define cplex model

%zdual.Param.mip.tolerances.absmipgap.Cur=gap;
%add q variables

%add the final constraints
[m,n]=size(A);
nconst=max(iv);
nvars=max(jv);

annzeros=n+nnz(A);
iva=zeros(annzeros,1);
jva=iva;
vva=iva;
u=1;
for j=1:n
    iva(u)=nconst+j;
    jva(u)=j;
    vva(u)=-1;
    u=u+1;
    for i=1:m
        if (A(i,j)~=0)
            iva(u)=nconst+j;
            jva(u)=nvars+i;
            vva(u)=A(i,j);
            u=u+1;
        end
    end
end
rhsa=zeros(n,1);
lhsa=rhsa-inf;
lba=zeros(m,1);
uba=lba+inf;
ctypea=blanks(m);
for i=1:m
    ctypea(i)='C';
end
obja=b;
%full version
ctype=[ctype,ctypea];
obj=[vec;obja];
lb=[lb;lba];
ub=[ub';uba];
lhs=[lhs;lhsa];
rhs=[rhs;rhsa];
iv=[iv;iva];
jv=[jv;jva];
vv=[vv;vva];

zdual=Cplex('zdual');
zdual.Model.sense='maximize';
zdual.Model.ctype=ctype;
zdual.Model.obj=obj;
zdual.Model.lb=lb;
zdual.Model.ub=ub;
zdual.Model.lhs=lhs;
zdual.Model.rhs=rhs;
zdual.Model.A=sparse(iv,jv,vv);
zdual.solve();
zdual.Param.mip.tolerances.mipgap.Cur=gap;
if (zdual.Solution.status<=102)
    v=zdual.Solution.objval;
    x=zdual.Solution.x;
    c=x(1:n);
else
    v=0;
    c=0;
    zdual.Solution.status
    disp('problem');
    flag=1;
end

time=toc;
    







