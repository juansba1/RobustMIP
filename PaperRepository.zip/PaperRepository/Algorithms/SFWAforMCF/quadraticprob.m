function [phi,y]=quadraticprob(A,b,c,mu)
[m,n]=size(A);
slp=Cplex('quadratic');
slp.Model.obj=[1;zeros(n,1)];
slp.Model.lb=[-inf;zeros(n,1)];
slp.Model.ub=[inf;inf+ones(n,1)];
slp.Model.lhs=b;
slp.Model.rhs=b+inf;
slp.Model.A=sparse([zeros(m,1),A]);
slp.Model.sense='minimize';
slp.addQCs([1;-c],-mu*[zeros(1,n+1);zeros(n,1),eye(n)],'G',0);
slp.Param.barrier.display.Cur=0;
slp.solve();
y=slp.Solution.x;
phi=y(1);
y=y(2:n+1);