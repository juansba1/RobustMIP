function [yK,cK,psiK,times,vals,gap,exitf,vM,osoltime,K,relgap]=FWNmcfFinal(M,clb,cub,b,ba,r,w,spl,spu,K,solvedual,delta,G,mode,epsilon2,olimit,timelimit)
tic;
%INPUTS
%M is the node arc adjacency matrix
%b is the vector of nodes' demands
%u is the vector of arcs' capacities
%cini is the intial cost of operating the arcs
%p1 is the x-location of the arcs
%p2 is the y-location of the arcs
%d is the increase in the distances after the attacks
%q is the radious defining each concentric region
%K is the number of iterations of the algortihm
%solvedual is 1 if z_D is used to obtain an initial solution, 0 otherwise
%delta is the approximated value of each FW iteration
%mode=1 if the update is the easy, 2 if it is line search, \ge 3 if it is
%the convex hull update

%OUTPUTS
%phi is the value of \phi_\mu(c^K)
%

%decreasing the gap improves, use the alpha by line search
gap=inf;
relgap=inf;
fiter=0;
gapv=zeros(K+1,1);
gamma=0;
times=zeros(K+1,1);
[~,n]=size(M);
CH=zeros(n,K+1);
%find the value of D2
u=ones(n,1)*b(1);
%D2=-nominalLP([M;-M;-eye(n)],[b;-b;-u],-ones(n,1));
%D2^2
%|y|^2_2\le n|y|^2_{\infty}
D2=n*b(1)^2;
%D2=D2^2;
if (solvedual==1)%get a very good inital solution by solving z_D. It might take a very long time
    [~,ci,~,oflag]=zdualre(M,cini,p1,p2,d,q,[M;-M;-eye(n)],[b;-b;-u],10^(-4));
    timeini=0;
else%put as initial solution the average of the lower and upper bounds
    ci=(clb+cub)/2;
    timeini=0;
    oflag=0;
end 

if (oflag==1)
    yK=0;
    cK=0;
    psiK=0;
else
    vM=[];
    vMK=[];
    cK=0;
    psiK=0;
    yK=0;
    vals=zeros(K+1,1);
    lb=vals;
    apsiK=inf;
    absgap=10^(-6);
    i=1;
    while ((i<=K+1)&&(toc<=olimit))
        [phi,yi]=quadraticprob([M;-M;-eye(n)],[b;-b;-u],ci,1/D2);
        if (i>1)
            if (delta>0)
                absgap=1/2*delta*gamma*CFL;
            else
                absgap=10^(-6);
            end
            [vi,cihat,vM,time,exitf,xk]=CoptspbigM(M,clb,cub,ba,r,w,spl,spu,yi,vM,absgap,timelimit);
            timelimit=timelimit-toc;
            cihat=improveC(cihat,xk,cub,yi);
            if (exitf~=0)%MIP was not solved to the desired conditions. Stop the algorithm, return the gap and the best solution found so far
                iter=i;
                i=K+2;
                vals(iter:K+1)=[];
                psiK=min(vals);
            end
        else%in the first iteration solve the problem to optimality and find an upper bound for the curvature constant
            [vi,cihat,vM,time,exitf,xk]=CoptspbigM(M,clb,cub,ba,r,w,spl,spu,yi,[],10^(-6),timelimit);
            timelimit=timelimit-toc;
            cihat=improveC(cihat,xk,cub,yi);
            psiK=vi;
            if (exitf~=0)%MIP was not solved to the desired conditions. Stop the algorithm
                iter=i;    
                i=K+2;
            else
                [phi2,~]=quadraticprob([M;-M;-eye(n)],[b;-b;-u],cihat,1/D2);
                %CFL is the lower bound in the curvature constant
                CFL=2*(phi+yi'*(cihat-ci)-phi2);
%                 vi
%                 1/2*CFL
%                 (vi+1/2*CFL)/vi
%                 dd=2*vi*(1.33-1)/CFL
%                 (vi+1/2*CFL*dd)/vi
%                 pause
                %redefine delta
                delta=min(floor(2*vi*G/CFL),40);
                %K=delta;
            end
        end
        if (exitf==0)
            %modify chat           
            vals(i)=cihat'*yi+absgap;
            lb(i)=ci'*yi;
            relgap=(min(vals(1:i))-max(lb(1:i)))/min(vals(1:i));
            gap=min([gap,cihat'*yi+absgap-ci'*yi]);
            gapv(i)=cihat'*yi+absgap-ci'*yi;
            CH(:,i)=cihat;
            times(i)=time;
            if (gapv(i)<epsilon2)%a solution within epsilon+1 has been found
                fiter=i;
                vMK=vM;
                i=K+2;
            end
        else
            if (iter==1)
                vals(1:K+1)=psiK;
            else
                if (iter>1)
                    vals(iter:K+1)=min(vals(1:iter-1));
                else
                    vals=0;
                end
            end
        end
        if ((i>2*K/3)&&(i<=K+1))
            if (vi<apsiK)
                apsiK=vi;
                yK=yi;
                vMK=vM;
            end
        end
        if (i<K+1)%updating mode
            gamma=(2/(i-1+2));
            if (mode==1)%basic
                ci=(1-gamma)*ci+gamma*cihat;
            else
                if (mode==2)%line search
                    ci=optoveralpha([M;-M;-eye(n)],[b;-b;-u],1/D2,ci,cihat);              
                else
                    ci=optoverconvex([M;-M;-eye(n)],[b;-b;-u],1/D2,CH(:,1:i));
                end
            end     
        end
        i=i+1;
    end%while exit
    
    if ((toc>olimit)&&(i<=K+2))
        exitf=-2;
        if (i>=2)
            vals(i:K+1)=min(vals(1:i-1));
        else
            vals=0;
        end
         
    end
    %plot(1:K+1,vals)
    %solve vMK
    if ((isempty(vMK)==0)&&(exitf==0))
        vMK.Param.mip.tolerances.absmipgap.Cur=10^(-6);
        vMK.solve();
        if (vMK.Solution.status>102)
            disp('problem');
            yK=0;
            cK=0;
            psiK=0;
        else
            x=vMK.Solution.x;
            cK=x(1:n);
            psiK=vMK.Solution.objval;
            if (fiter>0)
                vals(fiter:K+1)=psiK;
            end
        end 
    end
end
times=[timeini;times];
osoltime=toc;
