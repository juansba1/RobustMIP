function [H,dist]=computeC(G,d,q,p1,p2,c0)

n=max(size(p1));
g=size(G,1);
H=zeros(n,g);
dist=zeros(n,1);

for i=1:g
    for j=1:n
        %compute the costs for arc j associated with point i in the grid
        p=[p1(j),p2(j)];
        dist(j)=norm(p-G(i,:),1);
        %
        idx=computeIndex(dist(j),q);
        H(j,i)=c0(j)+d(idx);
    end
end