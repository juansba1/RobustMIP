function finalC=checkAlpha(alpha,ct,yt,dist,q,d,cini,alg)
%alg=0: FW, anyother number, not FW

K=max(size(q));
n=max(size(alpha));

finalC=alpha;
if ((alpha'*yt-ct'*yt>=10^(-3))&& (alg~=0))%this is the problematic case. In the FW approximated solution it is alright
    disp('alpha*yt-ct*yt>=10^(-3)>0, potential error');
    finalC=0;
else 
    if (alpha'*yt-ct'*yt<-10^(-3))% Most likely a rounding error. Check!
        for j=1:n
            if (yt(j)>10^(-5))% j is used
                if (ct(j)-alpha(j)>10^(-3))%c(j) larger than alpha(j), probably an approximation error. CHeck
                    flag=0;
                    for k=1:K
                        if (abs(dist(j)-q(k))<10^(-2))%this is likely a rounding problem, just set alpha(j) equal to ct(j)
                            finalC(j)=ct(j);
                            flag=1;
                        end
                    end
                    if (flag==0)
                        disp('ct(j)-alpha(j)>10^(-3) but alpha(j) was correctly calculated');
                        finalC=0;
                    end
                else%if alpha(j) is larger than c(j), probably an approximation error.
                    flag=0;
                    for k=1:K
                        if (abs(dist(j)-q(k))<10^(-2))%this is likely a rounding problem, just set alpha(j) equal to ct(j)
                            finalC(j)=ct(j);
                            flag=1;
                        end
                    end
                    if (flag==0)
                        disp('alpha(j)-c(j)>10^(-3) but alpha(j) was correctly calculated');
                        finalC=0;
                    end
                end
            end
        end
    end
end
