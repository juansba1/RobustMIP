function idx=computeIndex(dist,d)
K=max(size(d));
i=1;
while (i<=K)
    if (dist<=d(i)+10^(-3))%in case that is very close to a border, assume that i is located in the area with the most damage
        idx=i;
        i=K+2;
    else
        i=i+1;
    end
end