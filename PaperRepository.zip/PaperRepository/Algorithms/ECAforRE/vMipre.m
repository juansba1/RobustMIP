function [v,c,vM,time,alpha,exit]=vMipre(M,c0,p1,p2,d,q,y,vM,gap,timelimit)
exit=0;
%c0=c0';
[~,n]=size(M);
K=max(size(d));
nvars=n*(K+5)+2;
xM=max(p1);
xm=min(p1);
yM=max(p2);
ym=min(p2);
qmax=xM-xm+yM-ym;
if (isempty(vM)==1)    
    nnzeros=n*(6*K+7);
    nrows=n*(K+3);
    iv=zeros(nnzeros,1);
    jv=zeros(nnzeros,1);
    vv=zeros(nnzeros,1);
    rhs=zeros(nrows,1);
    lhs=rhs;
    u=1;
    z=0;
    QM=zeros(n,1);
    for j=1:n
        QM(j)=max([abs(p1(j)-xm),abs(p1(j)-xM)])+max([abs(p2(j)-ym),abs(p2(j)-yM)]);
        %QM(j)=120;
    end
    %def of \hat c
    for i=1:n
        iv(u)=z+i;
        jv(u)=i;
        vv(u)=1;
        u=u+1;
        for k=1:K
            iv(u)=z+i;
            jv(u)=2+5*n+(k-1)*n+i;
            vv(u)=-d(k);
            u=u+1;         
        end
        rhs(z+i)=c0(i);
        lhs(z+i)=c0(i);
    end
    z=z+n;
    %def of p1
    for i=1:n
       iv(u)=z+i;
       jv(u)=n+1;
       vv(u)=-1;
       u=u+1;
       iv(u)=z+i;
       jv(u)=2+n+i;
       vv(u)=-1;
       u=u+1;
       iv(u)=z+i;
       jv(u)=2+2*n+i;
       vv(u)=1;
       u=u+1; 
       rhs(z+i)=-p1(i);
       lhs(z+i)=-p1(i);
    end
    z=z+n;
    %def of p2
    for i=1:n
       iv(u)=z+i;
       jv(u)=n+2;
       vv(u)=-1;
       u=u+1;
       iv(u)=z+i;
       jv(u)=2+3*n+i;
       vv(u)=-1;
       u=u+1;
       iv(u)=z+i;
       jv(u)=2+4*n+i;
       vv(u)=1;
       u=u+1; 
       rhs(z+i)=-p2(i);
       lhs(z+i)=-p2(i);
    end
    z=z+n;
    %distances definition
    for k=1:K
        for i=1:n
           iv(u)=z+n*(k-1)+i;
           jv(u)=2+n+i;
           vv(u)=1;
           u=u+1;
           iv(u)=z+n*(k-1)+i;
           jv(u)=2+2*n+i;
           vv(u)=1;
           u=u+1;
           iv(u)=z+n*(k-1)+i;
           jv(u)=2+3*n+i;
           vv(u)=1;
           u=u+1;
           iv(u)=z+n*(k-1)+i;
           jv(u)=2+4*n+i;
           vv(u)=1;
           u=u+1;
           iv(u)=z+n*(k-1)+i;
           jv(u)=2+5*n+(k-1)*n+i;
           vv(u)=QM(i)-q(k);
           u=u+1;
           rhs(z+n*(k-1)+i)=QM(i);
           lhs(z+n*(k-1)+i)=-inf;
        end      
    end
    iv(u:nnzeros)=[];
    jv(u:nnzeros)=[];
    vv(u:nnzeros)=[];
    %objective function and bounds
    vec=zeros(nvars,1);
    lb=vec;
    %upper bounds
    vec=c0;
    for k=1:K
        vec=vec+d(k)*ones(n,1);
    end
    ub(1:n)=vec;
    ub(n+1)=xM;
    ub(n+2)=yM;
    vec=xM-xm;
    ub(n+3:2*n+2)=vec;
    ub(2*n+3:3*n+2)=vec;
    vec=yM-ym;
    ub(3*n+3:4*n+2)=vec;
    ub(4*n+3:5*n+2)=vec;
    ub(5*n+3:nvars)=ones(n*K,1);

    %obj
    vec=zeros(nvars,1);
    vec(1:n)=y;
    %ctype
    ctype=blanks(nvars);
    for i=1:5*n+2
        ctype(i)='C';
    end
    for i=5*n+3:nvars
        ctype(i)='B';
    end
    %define cplex model
    zdual=Cplex('zdual');
    zdual.Model.sense='maximize';
    zdual.Model.ctype=ctype;
    zdual.Model.obj=vec;
    zdual.Model.lb=lb;
    zdual.Model.ub=ub;
    zdual.Model.lhs=lhs;
    zdual.Model.rhs=rhs;
    zdual.Model.A=sparse(iv,jv,vv);
    zdual.Param.mip.tolerances.absmipgap.Cur=gap;
    zdual.Param.timelimit.Cur=timelimit;
    zdual.Param.mip.display.Cur=0;
    zdual.solve();
    if (zdual.Solution.status<=102)
        time=zdual.Solution.time;
        v=zdual.Solution.objval;
        x=zdual.Solution.x;
        c=x(1:n);
        vM=zdual;
        vM.addRows(-inf,vec',v+gap);
        %x is divided as [c;alpha_1;alpha_2;beta_1^+;beta_1^-;beta_2^+;beta_2^-;\lambda]
        alpha1=x(n+1);
        alpha2=x(n+2);
%         beta1M=x(n+3:2+2*n);
%         beta1m=x(3+2*n:2+3*n);
%         beta2M=x(3*n+3:2+4*n);
%         beta2m=x(3+4*n:2+5*n);
%         Lambda=zeros(n,K);
%         for k=1:K
%              Lambda(:,k)=x(2+5*n+(k-1)*n+1:2+5*n+k*n);
%         end
        alpha=[alpha1,alpha2];
%         vec=[40/1.5,40/1.5^2,40/1.5^3,40/1.5^4,40/1.5^5];
%         Lambda=[vec;Lambda];
    else
        if (zdual.Solution.status==107)%stop. Report gap and iteration number
            v=zdual.Solution.bestobjval;
            c=0;
            time=inf;
            exit=1;
            vM=[];
            alpha=-1;
        else% some other reason for exiting
            v=0;
            c=0;
            time=inf;
            exit=-1;
            vM=[];
            alpha=-1;
        end
    end
else %     if (gap<=10^(-4))%rescue the last solution y and w^* and add it to the constraints as
    vec=zeros(nvars,1);
    vec(1:n)=y;
    vM.Model.obj=vec;
    vM.Param.mip.tolerances.absmipgap.Cur=gap;
    vM.Param.timelimit.Cur=timelimit;
    vM.solve();
    if (vM.Solution.status<=102)
        time=vM.Solution.time;
        v=vM.Solution.objval;
        x=vM.Solution.x;
        c=x(1:n); 
        vM.addRows(-inf,vec',v+gap);
        %x is divided as [c;alpha_1;alpha_2;beta_1^+;beta_1^-;beta_2^+;beta_2^-;\lambda]
        alpha1=x(n+1);
        alpha2=x(n+2);
%         beta1M=x(n+3:2+2*n);
%         beta1m=x(3+2*n:2+3*n);
%         beta2M=x(3*n+3:2+4*n);
%         beta2m=x(3+4*n:2+5*n);
%         Lambda=zeros(n,K);
%         for k=1:K
%              Lambda(:,k)=x(2+5*n+(k-1)*n+1:2+5*n+k*n);
%         end
        alpha=[alpha1,alpha2];
    else
        if (vM.Solution.status==107)
            time=vM.Solution.time;
            v=vM.Solution.bestobjval;
            %x=vM.Solution.x;
            c=0;
            exit=1;
            alpha=-1;
        else
            time=inf;
            v=0;
            %x=0;
            c=0;
            exit=-1;
            alpha=-1;
        end
    end
end

