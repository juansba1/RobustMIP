function [G,Gc,xu,yu]=getGrid(p1,p2,N)

xM=max(p1);
xm=min(p1);
xdist=xM-xm;
yM=max(p2);
ym=min(p2);
ydist=yM-ym;
G=zeros(N^2,2);

xu=xdist/(N-1);
yu=ydist/(N-1);

x0=xm;
y0=ym;
u=1;
Gc=[1,N,N^2-N+1,N^2];
for i=1:N
    for j=1:N
        G(u,2)=y0+yu*(i-1);
        G(u,1)=x0+xu*(j-1);
        u=u+1;
    end
end