function [G,xu,yu]=updateGrid(G,Gc,xu,yu,N)
%G is the list with the gridpoints
%Gc has the extreme points of the grid
%xu is the x-distance between two consecutive points of the grid
%yu is the y-distance between two consecutive points in the grid
c0=G(Gc(1),:);
x0=c0(1);
y0=c0(2);

np=(N-1)*(3*N-2)+N-1;

Ga=zeros(np,2);

u=1;
%add points in the old x lines
x0a=x0+xu/2;
for i=1:N-1
    for j=1:N
        Ga(u,1)=x0a+(i-1)*xu;
        Ga(u,2)=y0+(j-1)*yu;
        u=u+1;
    end
end

%add points in the old y lines
y0a=y0+yu/2;
for i=1:N
    for j=1:N-1
        Ga(u,1)=x0+(i-1)*xu;
        Ga(u,2)=y0a+(j-1)*yu;
        u=u+1;
    end
end

%add thepoints in the middle

for i=1:N-1
    for j=1:N-1
        Ga(u,1)=x0a+(i-1)*xu;
        Ga(u,2)=y0a+(j-1)*yu;
        u=u+1;
    end
end

G=[G;Ga];
xu=xu/2;
yu=yu/2;
        
