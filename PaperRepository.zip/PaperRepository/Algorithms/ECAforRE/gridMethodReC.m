function [vt,iter,time,titer,exitf,qt,yt]=gridMethodReC(M,b,cini,p1,p2,d,q,N,epsilon,gap,olimit,timelimit)
%M node arc adjacency matrix
%b is the supply/demand vector
%cini is the initial cost vector of the network
%p1 is the vector with x-coordinate of all arcs
%p2 is the vector with y-coordinate of all arcs
%d is the cost vector with the increase differentials after attack
%q is the vector with the ripples radii
%N is the number of grid points in the x-axis
%epsilon is the tolerance for absolute gap
%olimit is the overall time limit for running the algorithm
%timelimit is the time limit for all the MIPs

%vt is the value of the optimal solution
%iter is the number of solved MIP
%time is the total time to run the algorithm
%yt is an epsilon-optimal robust solution


dold=d;
tic;
flag=0;
iter=0;
G=[];
qtM=[];
%fixd
d=fixd(d);
titer=0;
while ((flag==0)&&(toc<=olimit))
    if (isempty(G))
        [G,Gc,xu,yu]=getGrid(p1,p2,N);
        %get the initial H
        H=computeC(G,d,q,p1,p2,cini);
        %get the first Ht
        Ht=[H(:,Gc(1)),H(:,Gc(2)),H(:,Gc(3)),H(:,Gc(4))];
    else
        %refine G
        sg1=size(G,1);
        [G,xu,yu]=updateGrid(G,Gc,xu,yu,N);
        sg2=size(G,1);
        %update H 
        H2=computeC(G(sg1+1:sg2,:),d,q,p1,p2,cini);     
        [alphaH,dist]=computeC(alphat,d,q,p1,p2,cini);    
        %check ct and alpha. Approximation and rounding errors can happen
        %here that can mess up the algorithm
        finalC=checkAlpha(alphaH,ct,yt,dist,q,d,cini,1);
        H=[H,finalC,H2];    
        qtM.addRows(0,[1,-finalC'],inf);
    end
    [qt,yt,qtM,ctlmax,lpiter]=REcomputeqtS([M;-M],[b;-b],H,Ht,qtM);
    titer=titer+lpiter;
    if (iter==0)
        [vt,ct,vM,soltime,alphat,exitf]=vMipre(M,cini,p1,p2,dold,q,yt,[],gap,timelimit);
        timelimit=timelimit-soltime;
    else
        [vt,ct,vM,soltime,alphat,exitf]=vMipre(M,cini,p1,p2,dold,q,yt,vM,gap,timelimit);
        timelimit=timelimit-soltime;
    end
    if (vt-qt<epsilon)  
        flag=1;
        iter=iter+1;
        titer=titer+1;
    else
        if (exitf==0)
            iter=iter+1;
            titer=titer+1;
        else
            flag=1;
        end
    end
    if (toc>olimit)
        exitf=-2;
    end
end
time=toc;