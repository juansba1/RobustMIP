function [rtl,ctl,ctlmax]=maxGrid(y,H,qtl)

rtl=-inf;
[n,g]=size(H);
i=1;
ctl=zeros(n,g);
u=1;
while (i<=g)
    v=y'*H(:,i);
    if (v>rtl)
        rtl=v;
        ctlmax=H(:,i);
    end
    if (v>qtl+10^(-3))
        ctl(:,u)=H(:,i);
        u=u+1;
        i=g+1;
    end
    i=i+1; 
end
ctl(:,u:g)=[];
