function [vt,iter,time,titer,exitf,qt]=gridMethodMcf(M,b,ba,r,clb,cub,w,spl,spu,N,epsilon,gap,olimit,timelimit)
%M node arc adjacency matrix
%b is the supply demand vector
%ba is the attacker's supply demand vector
%r is the vector with the arcs' flows known by the defender, has an inf if
%the flow in an arc is not known
%clb is the vector with the costs lower bounds
%cub is the vector with the costs upper bounds
%w is the optimal solution of the attacker's problem
%spl and spu are vectors with lower and upper bounds on the dual variables
%of the attacker's mcf problem
%N is the number of paths to sample
%epsilon is the tolerance for the absolute gap
%gap is the relative gap of the MIPs
%olimit is the overall time limit
%timelimit is the time limit for the MIP

%vt is an epsilon optimal solution of the problem
tic;
flag=0;
iter=0;
qold=[];
H=[];
as=1;
qtM=[];
n=size(M,2);
titer=0;

while ((flag==0)&&(toc<=olimit))
    if (isempty(H))
        [H,rsol,PREV,Y]=gridMcf2(M,ba,as,r,clb,cub,w,N,[],[]);
        %get the first Ht
        Ht=H;
    else
        %refine G
        [H2,rsol,PREV,Y]=gridMcf2(M,ba,as,r,clb,cub,w,N,rsol,PREV);
        finalC=improveC(ct,xk,cub,yt);
        H=[H,H2,finalC];
        %add alphat to the constraints     
        qtM.addRows(0,[1,-finalC'],inf);
    end
    [qt,yt,qtM,ctlmax,lpiter]=REcomputeqtS([M;-M],[b;-b],H,Ht,qtM);
    qold=qt;
    titer=titer+lpiter;
    if (iter==0)
        [vt,ct,vM,~,exitf,xk]=CoptspbigM(M,clb,cub,ba,r,w,spl,spu,yt,[],gap,timelimit);
        timelimit=timelimit-toc;
    else
        %add ctlmax as an MIP start
         [vt,ct,vM,~,exitf,xk]=CoptspbigM(M,clb,cub,ba,r,w,spl,spu,yt,vM,gap,timelimit);
         timelimit=timelimit-toc;
    end
    if (abs(vt-qt)<epsilon)  
        flag=1;
        iter=iter+1;
    else 
        if (exitf==0)
            iter=iter+1;
            titer=titer+1;
        else
            iter=-1;
            flag=1;
        end
    end
    if (toc>olimit)
        exitf=-2;
    end
end
time=toc;