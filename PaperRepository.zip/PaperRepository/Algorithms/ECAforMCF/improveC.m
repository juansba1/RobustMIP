function ct=improveC(ct,xk,cub,yt)

n=max(size(ct));

for j=1:n
    if (yt(j)<10^(-5))&&(xk(j)<10^(-5))
        ct(j)=cub(j);
    end
end