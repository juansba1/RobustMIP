function [qt,yt,qtM,ctlmax,iter]=REcomputeqtS(A,b,H,Ht,qtM)
n=size(A,2);
if (isempty(qtM))
    aux=size(Ht,2);
    qtM=Cplex('qt');
    obj=[1;zeros(n,1)];
    lb=zeros(n+1,1);
    ub=lb+inf;
    lb(1)=-inf;
    lhs=[b;zeros(aux,1)];
    rhs=lhs+inf;
    AH=[ones(aux,1),-Ht'];
    A=[zeros(size(A,1),1),A];
    qtM.Model.sense='minimize';
    qtM.Model.obj=obj;
    qtM.Model.lb=lb;
    qtM.Model.ub=ub;
    qtM.Model.lhs=lhs;
    qtM.Model.rhs=rhs;
    qtM.Model.A=[A;AH];
end
size(qtM.Model.A)
flag=0;
iter=1;
while (flag==0)
    qtM.solve();
    qtl=qtM.Solution.objval;
    sol=qtM.Solution.x;
    ytl=sol(2:n+1);
    %compute rtl
    [rtl,ctl,ctlmax]=maxGrid(ytl,H,qtl);
    if (abs(rtl-qtl)<0.001)
        qt=qtl;
        yt=ytl;
        flag=1;
    else%add ctl to the constraints
        np=size(ctl,2);
        for i=1:np
            qtM.addRows(0,[1,-ctl(:,i)'],inf);
        end
    end 
    iter=iter+1;
end


