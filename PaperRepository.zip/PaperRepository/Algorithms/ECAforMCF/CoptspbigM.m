function [v,c,vM,time,exit,xk]=CoptspbigM(M,clb,cub,ba,r,w,spl,spu,y,vM,gap,timelimit)
[m,n]=size(M);
nvars=3*n+m;
exit=0;
if (isempty(vM)==1)    
    %compute the bounds for v
    vbounds=zeros(n,1);
    for j=1:n
        vec=M(:,j);
        [~,ii]=max(vec);
        [~,jj]=min(vec);
        if (isinf(r(j))||(r(j)==0))
            vbounds(j)=cub(j)+spu(ii)-spl(jj);
        end
    end 
    nnzeros=3*nnz(M)+5*n+nnz(ba);
    nrows=3*n+m+1;
    iv=zeros(nnzeros,1);
    jv=zeros(nnzeros,1);
    vv=zeros(nnzeros,1);
    rhs=zeros(nrows,1);
    lhs=rhs;
    u=1;
    z=1;
    %My=ba
    for i=1:m
        for j=1:n
            if (M(i,j)~=0)
                iv(u)=z;
                jv(u)=n+j;
                vv(u)=M(i,j);
                u=u+1;
            end
        end
        rhs(z)=ba(i);
        lhs(z)=ba(i);
        z=z+1;
    end
    %-M^\top \alpha-c\le 0
    for j=1:n
        iv(u)=z;
        jv(u)=j;
        vv(u)=-1;
        u=u+1;
        for i=1:m
            if (M(i,j)~=0)
                iv(u)=z;
                jv(u)=2*n+i;
                vv(u)=-M(i,j);
                u=u+1;
            end 
        end
        lhs(z)=-inf;
        z=z+1;
    end
    %y-v\le 0
    %compute total supply
    supply=0;
    for i=1:m
        if (ba(i)>0)
            supply=supply+ba(i);
        end
    end 
    %add the constraints
    for j=1:n
        iv(u)=z;
        jv(u)=n+j;
        vv(u)=1;
        u=u+1;
        iv(u)=z;
        jv(u)=2*n+m+j;
        vv(u)=-1*supply;
        u=u+1;
        lhs(z)=-inf;
        z=z+1;
    end
    %c+M^\top\alpha+diag(u)v\le u
    for j=1:n       
        iv(u)=z;
        jv(u)=j;
        vv(u)=1;
        u=u+1;
        for i=1:m
            if (M(i,j)~=0)
                iv(u)=z;
                jv(u)=2*n+i;
                vv(u)=M(i,j);
                u=u+1;
            end 
        end
        iv(u)=z;
        jv(u)=2*n+m+j;
        vv(u)=vbounds(j);
        u=u+1;
        rhs(z)=vbounds(j);
        lhs(z)=-inf;
        z=z+1;
    end
    %-ba^\top \alpha=w^*
    for i=1:m
        iv(u)=z;
        jv(u)=2*n+i;
        vv(u)=-ba(i);
        u=u+1;
    end
    rhs(z)=w;
    lhs(z)=w;
    z=z+1;
    
    iv(u:nnzeros)=[];
    jv(u:nnzeros)=[];
    vv(u:nnzeros)=[];
    rhs(z:nrows)=[];
    lhs(z:nrows)=[];
    type=blanks(nvars);
    for i=1:2*n+m
        type(i)='C';
    end
    for i=2*n+m+1:nvars
        type(i)='B';
    end
    


    %objective function and bounds
    obj=zeros(nvars,1);
    lb=obj;
    ub=lb+inf;
    obj(1:n)=y;
    %bounds in the cost vector
    lb(1:n)=clb;
    ub(1:n)=cub;
    %spl\le alpha\le spu
    lb(2*n+1:2*n+m)=spl;
    ub(2*n+1:2*n+m)=spu;
    %the intitial source node dual is 0
    %ub(2*n+as)=0;
    ub(2*n+m+1:nvars)=ones(n,1);
    %y=r
    for j=1:n
        if (isinf(r(j))==0)
            lb(n+j)=r(j);
            ub(n+j)=r(j);
            if (r(j)>10^(-5))
                lb(2*n+m+j)=1;
                ub(2*n+m+j)=1;
            else
                lb(2*n+m+j)=0;
                ub(2*n+m+j)=0;
            end
        end
    end
    zdual=Cplex('zdual');
    zdual.Model.sense='maximize';
    zdual.Model.ctype=type;
    zdual.Model.obj=obj;
    zdual.Model.lb=lb;
    zdual.Model.ub=ub;
    zdual.Model.lhs=lhs;
    zdual.Model.rhs=rhs;
    zdual.Model.A=sparse(iv,jv,vv);
    %add new cut
    high=cub'*y;
    low=clb'*y;
    zdual.addRows(low,obj',high);
    D=high-low;
    vec=zeros(1,nvars);
    vec(1:n)=-y';
    vec(n+1:2*n)=-D*y';
    zdual.addRows(-inf,vec,-high);
    zdual.Param.mip.display.Cur=0;
    zdual.Param.mip.tolerances.absmipgap.Cur=gap;
    zdual.Param.timelimit.Cur=timelimit;
    zdual.solve();
    if (zdual.Solution.status<=102)
        time=zdual.Solution.time;
        v=zdual.Solution.objval;
        x=zdual.Solution.x;
        c=x(1:n);
        xk=x(n+1:2*n);
        vM=zdual;
        vM.addRows(-inf,obj',v+gap);
    else
        if (zdual.Solution.status==107)%timelimit reached
            v=zdual.Solution.bestobjval;
            c=0;
            xk=0;
            time=inf;
            exit=zdual.Solution.miprelgap;
            vM=[];
        else% some other reason for exiting
            v=0;
            c=0;
            xk=0;
            time=inf;
            exit=-1;
            zdual.Solution.status
            pause
            vM=[];
        end
    end
else
    %just change the objective function
    vec=zeros(nvars,1);
    vec(1:n)=y;
    vM.Model.obj=vec;
    vM.Param.mip.tolerances.absmipgap.Cur=gap;
    
    %add new cut
    high=cub'*y;
    low=clb'*y;
    vM.addRows(low,vec',high);
    D=high-low;
    vec2=zeros(1,nvars);
    vec2(1:n)=-y';
    vec2(n+1:2*n)=-D*y';
    vM.addRows(-inf,vec2,-high);
    vM.solve();
    if (vM.Solution.status<=102)
        time=vM.Solution.time;
        v=vM.Solution.objval;
        x=vM.Solution.x;
        c=x(1:n); 
        xk=x(n+1:2*n);
        vM.addRows(-inf,vec',v+gap);

    else
        if (vM.Solution.status==107)
            time=vM.Solution.time;
            v=vM.Solution.bestobjval;
            c=0;
            xk=0;
            exit=vM.Solution.miprelgap;
        else
            time=inf;
            v=0;
            c=0;
            xk=0;
            exit=-1;
            vM.Solution.status
            pause
        end
    end
end