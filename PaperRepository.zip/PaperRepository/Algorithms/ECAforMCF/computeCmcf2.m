function [cM,cinv]=computeCmcf2(M,ba,y,w,clb,cub,cinv)
[m,n]=size(M);
%[~,sa]=max(ba);
%[~,sk]=min(ba);
if (isempty(cinv))
    cinv=Cplex('cinv');
    cinv.Model.sense='maximize';
    cinv.Model.obj=zeros(n+m,1);
    cinv.Model.lb=[clb;zeros(m,1)];
    cinv.Model.ub=[cub;zeros(m,1)+inf];
    %cinv.Model.ub(n+as)=0;
    cinv.Model.lhs=[w;zeros(n,1)-inf];
    cinv.Model.rhs=[w;zeros(n,1)];
    cinv.Model.A=[zeros(1,n+m);-eye(n),-M'];
    vec=zeros(1,n+m);
    vec(n+1:n+m)=-ba';
    cinv.addRows(w,vec,inf);
end
cinv.Model.A(1,1:n)=y';
cinv.solve();
if (cinv.Solution.status~=3)
   nz=nnz(y);
   entry=zeros(nz,1);
   cM=zeros(n,nz+1);
   c=cinv.Solution.x;
   cM(:,1)=c(1:n);
   k=1;
   for j=1:n     
       if (y(j)>10^(-5))
           entry(k)=j;
           k=k+1;
       end
   end
   vec=[ones(n,1);zeros(m,1)];
   for k=1:nz
       vec(entry(k))=0;
   end
   u=2;
   for k=1:nz
       vec(entry(k))=1;
       cinv.Model.obj=vec;
       cinv.solve();
       c=cinv.Solution.x;
       c=c(1:n);
       flag=0;
       r=1;
       while (r<=k)
           if (isequal(c,cM(:,r)))
               flag=1;
               r=k+1;
           else
               r=r+1;
           end
       end
       if (flag==0)
           cM(:,u)=c(1:n);
           u=u+1;
       end
       vec(entry(k))=0;
   end
   cM(:,u:nz+1)=[];
else
    cM=0;
end