function [H,rsol,PREV,Y]=gridMcf2(M,ba,as,r,clb,cub,w,N,rsol,PREV)
%PREV has paths already generated
[~,n]=size(M);
if (isempty(PREV))
    %create the Cplex model 
    rsol=Cplex('rsol');
    rsol.Model.sense='minimize';
    rsol.Model.obj=zeros(n,1);
    rsol.Model.lb=zeros(n,1);
    rsol.Model.ub=zeros(n,1)+inf;
    rsol.Model.lhs=ba;
    rsol.Model.rhs=ba;
    rsol.Model.A=M;
    for j=1:n
        if (isinf(r(j))==0)
            rsol.Model.lb(j)=r(j);
            rsol.Model.ub(j)=r(j);
        end
    end
    %add the constraints regarding the lower and upper bounds
    rsol.addRows(-inf,clb',w);
    rsol.addRows(w,cub',inf);
end
H=zeros(n,N*n);
r=1;
j=1;
v=0;
Y=[];
cinv=[];
u=size(PREV,2);
while (j<=N)
    %by putting an obj function c, at least we know that y is the sp with
    %respect to a c, thus is more likely that y is a sp with respect to a c
    %that satisfies the conditions of U
    ctemp=zeros(n,1);
    for i=1:n
        ctemp(i)=clb(i)+rand()*(cub(i)-clb(i));
    end
    rsol.Model.obj=ctemp;
    rsol.solve();    
    if (rsol.Solution.status~=3)
        %find the cost
        y=rsol.Solution.x;
        %avoid repeated solutions
        flag=0;
        for i=1:u
            if (isequal(y,PREV(:,i)))
                flag=1;      
            end
        end
        if (flag==0)
            u=u+1;
            PREV(:,u)=y;       
            [cM,cinv]=computeCmcf2(M,ba,y,w,clb,cub,cinv);
            if (isequal(cM,0)==0)
                for q=1:size(cM,2)
                    H(:,r)=improveC(cM(:,q),y,cub,zeros(n,1));
                    r=r+1;
                end
                j=j+1;        
            else%storeit into the infeasible solutions
                if (v==0)
                    Y=y;
                    v=v+1;
                else
                    Y(:,v)=y;
                    v=v+1;
                end
            end 
        else% if it is equal to a previous solution, 
            %stop and send the current H     
            j=N+1;
        end
    end
end
H(:,(r:N*n))=[];


