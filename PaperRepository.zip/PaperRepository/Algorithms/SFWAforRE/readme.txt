FWNreFinalT.m is the main file.
Place all .m files in the same folder.
To test: open the .mat file and run FWNreFinalT. Make sure to include values for the parameters not defined in the .mat file.