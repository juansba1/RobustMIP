function [phi,y]=nominalLP(A,b,c)
[~,n]=size(A);
slp=Cplex('Recovery');
slp.Model.obj=c;
slp.Model.lb=zeros(n,1);
slp.Model.ub=inf+ones(n,1);
slp.Model.lhs=b;
slp.Model.rhs=b+inf;
slp.Model.A=sparse(A);
slp.Model.sense='minimize';
slp.Param.lpmethod.Cur=1;
slp.solve();
y=slp.Solution.x;
phi=slp.Solution.objval;