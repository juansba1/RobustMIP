function [yK,cK,psiK,times,vals,gap,exitf,vM,osoltime,K,relgap]=FWNreFinalT(M,b,u,cini,p1,p2,d,q,K,solvedual,delta,G,mode,epsilon2,olimit,timelimit)
tic;
%INPUTS
%M node arc adjacency matrix
%b is the supply/demand vector
%cini is the initial cost vector of the network
%p1 is the vector with x-coordinate of all arcs
%p2 is the vector with y-coordinate of all arcs
%d is the cost vector with the increase differentials after attack
%q is the vector with the ripples radii
%u is the vector of arcs' flow capacities
%K is the number of iterations of the algortihm
%solvedual is 1 if z_D is used to obtain an initial solution, 0 otherwise
%(this option is not discussed in the paper and was not used in the results)
%delta is the approximated value of each FW iteration
%G is a bound on the curvature of the function
%mode=1 if the update is the easy, 2 if it is line search, \ge 3 if it is
%the convex hull update
%epsilon2 is the tolerance for dual gap of the algorithm (this option is
%not discussed in the paper and was not used in the results)
%olimit is the overall time limit for running the algorithm
%timelimit is the time limit for all the MIPs

%OUTPUTS
%psiK is the value of \psi^K
%yK is the value of y^k
%cK is the value of \har c^k
%relgap is the value of the relative gap reported from the upper and lower
%bounds of the algorithm

dfixed=fixd(d);
%decreasing the gap improves, use the alpha by line search
gap=inf;
relgap=inf;
fiter=0;
gapv=zeros(K+1,1);
gamma=0;
times=zeros(K+1,1);
[~,n]=size(M);
CH=zeros(n,K+1);
%find the value of D2
D2=-nominalLP([M;-M;-eye(n)],[b;-b;-u],-u);
if (solvedual==1)%get a very good inital solution by solving z_D. It might take a very long time
    [~,ci,~,oflag]=zdualre(M,cini,p1,p2,d,q,[M;-M;-eye(n)],[b;-b;-u],10^(-4));
    timeini=0;
else%put as initial solution the original cost vector of the network
    ci=cini;
    timeini=0;
    oflag=0;
end 
if (oflag==1)
    yK=0;
    cK=0;
    psiK=0;
else
    vM=[];
    yK=0;
    vals=zeros(K+1,1);
    lb=vals;
    apsiK=inf;
    absgap=10^(-6);
    i=1;
    while ((i<=K+1)&&(toc<=olimit))
        [phi,yi]=quadraticprob([M;-M;-eye(n)],[b;-b;-u],ci,1/D2);
        if (i>1)
            if (delta>0)
                absgap=1/2*delta*gamma*CFL;
            else
                absgap=10^(-6);
            end
            [vi,cihat,vM,time,alphat,exitf]=vMipre(M,cini,p1,p2,d,q,yi,vM,absgap,timelimit); 
            timelimit=timelimit-time;
            iter=i;
            if (exitf~=0)%MIP was not solved to the desired conditions. Stop the algorithm
                i=K+2;
                if (exitf==1)
                    vMK=vM;  
                end
            else
                [alphaH,dist]=computeC(alphat,dfixed,q,p1,p2,cini);
                cihat=checkAlpha(alphaH,cihat,yi,dist,q,dfixed,cini,0);
            end
        else%in the first iteration solve the problem to optimality and find an upper bound for the curvature constant
            [vi,cihat,vM,time,alphat,exitf]=vMipre(M,cini,p1,p2,d,q,yi,[],10^(-4),timelimit); 
            timelimit=timelimit-time;
            %get a better alternative optimal. It improves the objective
            %but degrades the solution time        
            iter=i;
            if (exitf~=0)%MIP was not solved to the desired conditions. Stop the algorithm
                i=K+2;
                yK=-1;
                cK=-1;
                psiK=-1;
                times=-1;
                vals=-1;
                gap=-1;
                vM=[];
                osoltime=-1;
                relgap=-1;
            else            
                [phi2,~]=quadraticprob([M;-M;-eye(n)],[b;-b;-u],cihat,1/D2);
                %CFL is the lower bound in the curvature constant
                CFL=2*(phi+yi'*(cihat-ci)-phi2);
                delta=min(floor(2*vi*G/CFL),40);
                [alphaH,dist]=computeC(alphat,dfixed,q,p1,p2,cini);
                cihat=checkAlpha(alphaH,cihat,yi,dist,q,dfixed,cini,0);
            end
        end
        if (exitf==0)
            vals(i)=cihat'*yi+absgap;
            lb(i)=ci'*yi;
            relgap=(min(vals(1:i))-max(lb(1:i)))/min(vals(1:i));
            gap=min([gap,cihat'*yi+absgap-ci'*yi]);
            gapv(i)=cihat'*yi+absgap-ci'*yi;
            CH(:,i)=cihat;                  
            times(i)=time;
            if (gapv(i)<epsilon2)%a solution within epsilon+1 has been found
                fiter=i;
                vMK=vM;
                i=K+2;
            end
        else
            if (iter>2)
                vals(iter:K+1)=min(vals(1:iter-1));
            else
                vals=0;
            end
        end
        if ((i>2*K/3)&&(i<=K+1))
            if (vi<apsiK)
                apsiK=vi;
                yK=yi;
                vMK=vM;
            end
        else
            if (i<2*K/3)
                vMK=[];
            end
        end
        if (i<K+1)%updating mode
            gamma=(2/(i-1+2));
            if (mode==1)%basic
                ci=(1-gamma)*ci+gamma*cihat;
            else
                if (mode==2)%line search
                    ci=optoveralpha([M;-M;-eye(n)],[b;-b;-u],1/D2,ci,cihat);              
                else
                    ci=optoverconvex([M;-M;-eye(n)],[b;-b;-u],1/D2,CH(:,1:i));
                end
            end     
        end
        i=i+1;
    end
    if (toc>olimit)
        exitf=-2;
        if (i>1)
            vals(iter:K+1)=min(vals(1:iter-1));
        else
            vals=0;
        end
    end
    %solve vMK
    if (isempty(vMK)==0)
        vMK.Param.mip.tolerances.absmipgap.Cur=0;
        vMK.Param.mip.tolerances.absmipgap.Cur=0;
        vMK.solve();
        if ((vMK.Solution.status~=101)&&(vMK.Solution.status~=102)&&(vMK.Solution.status~=107))
            disp('problem');
            yK=0;
            cK=0;
            psiK=0;
        else
            if (vMK.Solution.status<=102)
                x=vMK.Solution.x;
                cK=x(1:n);
                psiK=vMK.Solution.objval;
                if (fiter>0)
                    vals(fiter:K+1)=psiK;
                end
            else
                psiK=vMK.Solution.bestobjval;
                cK=0;
                
            end
        end 
    else
        yK=0;
        cK=0;
        psiK=0;
    end
end
times=[timeini;times];
osoltime=toc;

